<template><div class="app-root"><router-view /></div></template>
<script setup lang="ts"></script>
<style scoped>.app-root{min-height:100dvh;background:var(--td-bg-color-page,#f7f8fa);}</style>
