<template><div class="page"><div class="section"><t-card title="周周激励活动" subtitle="点击了解更多 GO"><template #actions><t-button size="small" theme="primary">查看详情</t-button></template></t-card></div><BottomTabBar/></div></template>
<script setup lang="ts">import BottomTabBar from '@/components/BottomTabBar.vue'</script>
<style scoped>.page{padding-bottom:64px;}.section{padding:12px;}</style>
